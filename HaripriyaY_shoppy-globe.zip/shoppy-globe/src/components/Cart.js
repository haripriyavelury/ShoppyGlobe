import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import CartItem from './CartItem';
import { clearCart } from '../redux/cartSlice';
import { Link } from 'react-router-dom';
import '../App.css';

const Cart = () => {
const cartItems = useSelector(state => state.cart.items);

console.log("cartItems",cartItems);
console.log("cartItems.length",cartItems.length);

const dispatch = useDispatch();

console.log("Items added to the cart: ",cartItems);

return (
<div className="cart">  
<h2>Shopping Cart</h2>
    {cartItems.length === 0 ? (
    <p>Your cart is empty.</p>
) : (<>
{cartItems.map((item) => 
(<CartItem className="cart-item" 
    key={item.id} item={item} />)
)}
<button className="clear-cart" 
onClick={() => dispatch(clearCart())}>
    Clear Cart</button>

<Link to="/checkout">  
     <button className="checkout">
        Proceed to Checkout</button>  
</Link></>
)}
</div>
);
};

export default Cart;