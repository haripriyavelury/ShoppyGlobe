import React from 'react';
import { useDispatch } from 'react-redux';
import { removeFromCart } from '../redux/cartSlice';

const CartItem = ({ item }) => {
const dispatch = useDispatch();

return (
<div className='cart-item'>  
     <img className="product-image" src= {item.thumbnail}></img>  
     <h4>Product: {item.title}</h4>  

     <p>Quantity: {item.quantity}</p>
     
    
 <p>{item.description}</p>
  <button onClick={() => dispatch(removeFromCart(item.id))}>Remove</button>
 </div>

 );
};

export default CartItem;