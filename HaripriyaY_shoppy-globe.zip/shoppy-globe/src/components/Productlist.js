import React ,{useState, useEffect } from 'react';
import ProductItem from './ProductItem';
import useFetchProducts from '../hooks/useFetchProducts';
import { fetchProducts } from '../redux/cartSlice';
import { addToCart } from '../redux/cartSlice';  
import { useDispatch, useSelector } from 'react-redux';


const Productlist = () => {
    //const dispatch = useDispatch();  
//const { product, error, loading } = useFetchProducts();



 const dispatch = useDispatch();  
 const products = useSelector((state) => state.cart.products || []);  
 const loading = useSelector((state) => state.cart.loading);  
 const error = useSelector((state) => state.cart.error);  
 const [searchTerm, setSearchTerm] = useState('');  


console.log("Initial Redux State:",  { products } );  
//console.log(products);
console.log("Initial Redux State:", { loading });  
console.log("Initial Redux State:", { error });  

useEffect(() => {  
  const fetchData = async() => {
  console.log("Component mounted, dispatching fetchProducts");  
 await dispatch(fetchProducts());
  // dispatch(fetchProducts())
  // .then((result) => {  
   console.log("Dispatched products", products);
    // result); // Log the result of the dispatch  
  };  
  fetchData();   
  // eslint-disable-next-line react-hooks/exhaustive-deps 
}, [dispatch]);  

console.log("products",products);//useSelector
//console.log(dispatch(fetchProducts()));
// console.log(result);

//   useEffect(() => {  
//     console.log("Updated Redux state: PRODUCTS", { products });  
//     dispatch(fetchProducts());
//     console.log(dispatch(fetchProducts()));
// }, [dispatch]);  

  // Log the products after the action is dispatched  
  useEffect(() => {  
    console.log("Redux State updated:");  
    console.log("Current products:", products);  
    console.log("Loading status:", loading);  
    console.log("Error status:", error);  
}, [products,loading,error]);  




if (loading) return <p>Loading...</p>;
if (error) return <p>There was an error fetching products.</p>;


//{/* <div> */}
// {products.map(product => (
//{/* <ProductItem key={product.id} product={product} /> */}
// ))}
//{/* </div> */}


return (
<>
  <button className="button" onClick={() => dispatch(fetchProducts())}>Reload Products</button>  
  <input className="input" type="text" placeholder="Search products..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />  
  <div className="product-list">  
  {loading ? (  
    <p>Loading products...</p>  
  ) : error ? (  
    <p>Error fetching products: {error}</p>  
  ) : !products || products.length === 0 ? (  
    <p>No Products Available</p>  
  ) : (  
    products.filter((product) =>  
        product.title.toLowerCase().includes(searchTerm.toLowerCase())  
      ).map((product) => (  
        <ProductItem key={product.id} product={product} />  
      ))  
  )}  
</div> 
</>


);
};

export default Productlist;