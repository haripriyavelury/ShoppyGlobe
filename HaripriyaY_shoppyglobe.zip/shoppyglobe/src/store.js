import { configureStore } from '@reduxjs/toolkit';  
import cartReducer from './redux/cartSlice';
//import { getDefaultMiddleware } from '@reduxjs/toolkit';

const store = configureStore({  
 reducer: {  
   cart: cartReducer,  
 },  
//  middleware: (getDefaultMiddleware)=>
//  getDefaultMiddleware({serializableCheck:false,}),
});  

export default store;  