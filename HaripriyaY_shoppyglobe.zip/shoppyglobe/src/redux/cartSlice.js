import { createSlice,createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';


// export const fetchProducts = createAsyncThunk('cart/fetchProducts',
//   async () => {  
  
export const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  
  // const response = await axios.get('https://dummyjson.com/products');  
  // //const response = await response('API_ENDPOINT');
  // if (!response.ok) {  
  //       throw new Error('Network response was not ok');  
  //   }  
  //   const data = await response.json();  
    
  //   console.log("API fetch data:", data);  
  //   console.log("API Response:", response.data);
  //   return response.data.products;
  //     //return response.data.products; // Return products array  
  // }); 



 try {  const response = await axios.get('https://dummyjson.com/products');  
  
  console.log("API Response:", response.data); //API response 
  if (response.data && response.data.products) 
    {  
      console.log("products in API Response:", response.data.products); 
    return response.data.products;
    }  
     
    else 
    {  
      console.error('No products found in the API response');  
      throw new Error('No products found');  
      // throw new Error("No products found");  
    }  
  }
catch (error) {  
  console.error('Error fetching products:', error);  
  // Throwing the error so it can be caught in the rejected case  
  throw error;  
} 

});  


// export const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  
//   return [  
//       { id: 1, name: 'Test Product 1' },  
//       { id: 2, name: 'Test Product 2' }  
//   ]; // This is for testing  
// });  

//console.log("products from API",fetchProducts());
const cartSlice = createSlice({  
 name: 'cart',  
 initialState: {  
  items:[],
   products: [],  
  //  loading:false,
  //  error:null,
 },  
 reducers: {  
   addToCart: (state, action) => {  
    const existingItem = state.items.find(item => item.id === action.payload.id);  
    if (existingItem) {  
      existingItem.quantity += 1; // track quantity  
    } else {  
      state.items.push({ ...action.payload, quantity: 1 }); // Add new item  
    }    
    console.log("Current cart state",state.items);
   },
   removeFromCart: (state, action) => {  
    state.items = state.items.filter(item => item.id !== action.payload);  
   },  
   clearCart: (state) => {  
     state.items = [];  
   },  },
   extraReducers: (builder) => {  
    builder  
      .addCase(fetchProducts.fulfilled, (state, action) => {  
        //state.products = action.payload || [{id: 1, name: 'Test Product'}];;  
        console.log("fetchProducts.fulfilled triggered");  
        console.log("Products payload", action.payload);
        state.products=action.payload;
        state.loading = false;
      })
      .addCase(fetchProducts.pending, (state) => {  
        state.loading = true;  
        state.error = null;
      })
      .addCase(fetchProducts.rejected, (state, action) => {  
        state.loading = false; // Set loading to false  
        state.error = action.error.message; // Set error message if needed  
        console.error('Failed to fetch products:', action.error.message); // Error handling    
      });
  }  
 },  
);  

export const { addToCart, removeFromCart, clearCart } = cartSlice.actions;  
export default cartSlice.reducer;  
