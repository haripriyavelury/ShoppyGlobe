import React from 'react';  
import { useDispatch } from 'react-redux';  
import { addToCart } from '../redux/cartSlice';
import { fetchProducts } from '../redux/cartSlice';
import '../App.css'; 

const ProductItem = ({ product }) => {  
 const dispatch = useDispatch();  


 const handleAddToCart = () => {  
  dispatch(addToCart(product));
  // dispatch(addToCart({ id: product.id, name: product.title, 
  //   description: product.description, price: product.price, rating: product.rating}));  
console.log("Item added to cart",product)};  

 return (  
   <div className='product-item'>  
   
   <img className="product-image" src={product.thumbnail} alt="{product.title}"/>
 
     <h3>{product.title}</h3>  
     <p>DESC: {product.description}</p>  
     <p>Price: {product.price}</p>
     <p>Rating: {product.rating}</p>
     <button className="button" onClick={handleAddToCart}>Add to Cart</button>  
   </div>  
 );  
};  

export default ProductItem;  