import React ,{useState, useEffect } from 'react';  
import { useDispatch, useSelector } from 'react-redux';
import ProductItem from './ProductItem';  
import { addToCart } from '../redux/cartSlice';  
//import store from '../store';
import { useFetchProducts } from '../hooks/useFetchProducts';
import { fetchProducts } from '../redux/cartSlice';


// const dummyProducts = [  
//   { id: 1, name: 'Product 1', description: 'This is product 1.' },  
//   { id: 2, name: 'Product 2', description: 'This is product 2.' },  
// ];  

//const products = dummyProducts;
const ProductList = () => {  

 const dispatch = useDispatch();  
 const products = useSelector((state) => state.cart.products);  
 const loading = useSelector((state) => state.cart.loading);  
 const error = useSelector((state) => state.cart.error);  
 const [searchTerm, setSearchTerm] = useState('');  


console.log("Initial Redux State:",  { products } );  
//console.log(products);
console.log("Initial Redux State:", { loading });  
console.log("Initial Redux State:", { error });  

useEffect(() => {  
  const fetchData = async() => {
  console.log("Component mounted, dispatching fetchProducts");  
 await dispatch(fetchProducts());
  // dispatch(fetchProducts())
  // .then((result) => {  
   console.log("Dispatched products", products);
    // result); // Log the result of the dispatch  
  };  
  fetchData();   
  // eslint-disable-next-line react-hooks/exhaustive-deps 
}, [dispatch]);  

console.log("products",products);//useSelector
//console.log(dispatch(fetchProducts()));
// console.log(result);

//   useEffect(() => {  
//     console.log("Updated Redux state: PRODUCTS", { products });  
//     dispatch(fetchProducts());
//     console.log(dispatch(fetchProducts()));
// }, [dispatch]);  

  // Log the products after the action is dispatched  
  useEffect(() => {  
    console.log("Redux State updated:");  
    console.log("Current products:", products);  
    console.log("Loading status:", loading);  
    console.log("Error status:", error);  
}, [products,loading,error]);  

//conditional rendering
if (loading) return <p>Loading products...</p>;  
if (error) return <p>There was an error fetching products.</p>;  

  // useEffect(() => {  
  //   //const fetchData = async () => 
  //     // {await dispatch(fetchProducts());
  //   dispatch(fetchProducts());  
  //     console.log("products",products); // Log the products  
  //  // };  
  //   //fetchData();  
  //   // eslint-disable-next-line react-hooks/exhaustive-deps 
  // }, [dispatch]);  



 return (  
  <>
  <button className="button" onClick={() => dispatch(fetchProducts())}>Reload Products</button>  
  <input className="input" type="text" placeholder="Search products..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />  
  <div className="product-list">  
  { loading ? (  
      <p>Loading products...</p>  
  ) : error ? (  
      <p>Error fetching products: {error}</p>  
  ) : (  
      products.length === 0 ? (  
          <p>No Products Available</p>  
      ) : (  
          // products.map((product) => (  
          //     <ProductItem key={product.id} product={product} />  
          // ))  
     products.filter((product) =>   
                    product.title.toLowerCase().includes(searchTerm.toLowerCase())  
                )  
                .map((product) => (  
                    <ProductItem  className="product-item" key={product.id} product={product}/>
                ))  

              )  
            )}  

</div>  </>
 );  
};  

export default ProductList;  