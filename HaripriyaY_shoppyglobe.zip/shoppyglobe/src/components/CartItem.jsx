import React from 'react';  
import { useDispatch } from 'react-redux';  
import { removeFromCart } from '../redux/cartSlice';
import '../App.css';   

const CartItem = ({ item }) => {  
 const dispatch = useDispatch();  

const handleRemove=()=>{
  dispatch(removeFromCart(item.id));

};

 return (  
   <div className='cart-item'>  
     <h4>Product: {item.title}</h4>  
     <p>Quantity: {item.quantity}</p>
     <button onClick={handleRemove}>Remove Item</button>  
   </div>  
 );  
};  

export default CartItem;  