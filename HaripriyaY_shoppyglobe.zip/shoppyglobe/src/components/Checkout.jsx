import React from 'react';  
import { useDispatch, useSelector } from 'react-redux';  
import { clearCart } from '../redux/cartSlice';  

const Checkout = () => {  
    const cartItems = useSelector((state) => state.cart.items);  
    const dispatch = useDispatch();  

    const handleCheckout = (event) => {  
        event.preventDefault();  
        // Here you can handle the checkout logic, like processing payment, etc.  
        alert("Thank you for your order!");  
        dispatch(clearCart()); // Clear the cart after checkout  
    };  

    if (cartItems.length === 0) {  
        return <p>Your cart is empty. Please add some items to checkout.</p>;  
    }  

    return (  
        <div className="checkout">  
            <h2>Checkout</h2>  
            <form onSubmit={handleCheckout}>  
                <h3>Your Items:</h3>  
                <ul>  
                    {cartItems.map((item) => (  
                        <li key={item.id}>  
                            <p>{item.title} (Quantity: {item.quantity})</p>  
                        </li>  
                    ))}  
                </ul>  
                <h3>Shipping Information:</h3>  
                <input type="text" placeholder="Full Name" required />  
                <input type="text" placeholder="Address" required />  
                <input type="text" placeholder="City" required />  
                <input type="text" placeholder="State" required />  
                <input type="number" placeholder="Zip Code" required />  
                <button type="submit">Complete Checkout</button>  
            </form>  
        </div>  
    );  
};  

export default Checkout; 