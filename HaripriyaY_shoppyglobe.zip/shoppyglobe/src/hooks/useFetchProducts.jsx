import { useState, useEffect } from 'react';  
import axios from 'axios';  
import {createAsyncThunk} from '@reduxjs/toolkit';

export const useFetchProducts = (id) => {  
 const [product, setProduct] = useState(null);
  //[]);  
 const [loading, setLoading] = useState(true);  
 const [error, setError] = useState(null);  
//true);


//  const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  
//   return [  
//       { id: 1, name: 'Test Product 1' },  
//       { id: 2, name: 'Test Product 2' }  
//   ]; // This is for testing  
// });  

 useEffect(() => {  
   const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  
    //  const response = await axios.get(`https://dummyjson.com/products${id ? `/${id}` : ''}`);  
    // console.log("API Response:", response.data); // Log the response  
    // return (response.data.products);  
     try {  
      //const response = await axios.get(`https://dummyjson.com/products`);  
      const response = await axios.get(`https://dummyjson.com/products${id ? `/${id}` : ''}`);  
       
       setProduct(response.data);
        //.products);  
       //return response.data;
      
     } catch (error) {  
       setError(true);  
     } finally {  
       setLoading(false);  
     }  
   });  

   fetchProducts();  
 }, [id]);  
 
 return { product, error, loading };  
};  

// export default useFetchProducts;  