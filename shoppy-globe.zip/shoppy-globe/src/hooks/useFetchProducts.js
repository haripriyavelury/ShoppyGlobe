import { useState, useEffect } from 'react';
import axios from 'axios';
import {createAsyncThunk} from '@reduxjs/toolkit';

// export const useFetchProducts = () => {
//  const [products, setProducts] = useState([]);
//  const [loading, setLoading] = useState(true);
//  const [error, setError] = useState(false);

export const useFetchProducts = (id) => {  
 const [product, setProduct] = useState(null);
  //[]);  
 const [loading, setLoading] = useState(true);  
 const [error, setError] = useState(null);  
//true);


 useEffect(() => {
  // const fetchProducts = async () => {
    const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  
    try {
       //const response = await axios.get('https://dummyjson.com/products');
             const response = await axios.get(`https://dummyjson.com/products${id ? `/${id}` : ''}`);
       setProduct(response.data.products);
     } catch (error) {
       setError(true);
     } finally {
       setLoading(false);
     }
   });

   fetchProducts();
 }, [id]);

 return { product, loading, error };
};

// export default useFetchProducts;