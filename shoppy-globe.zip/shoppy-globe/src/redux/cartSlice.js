import { createSlice,createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';


export const fetchProducts = createAsyncThunk('cart/fetchProducts', async () => {  

 try {  const response = await axios.get('https://dummyjson.com/products');  
  
  console.log("API Response:", response.data); //API response 
  if (response.data && response.data.products) 
    {  
      console.log("products in API Response:", response.data.products); 
    return response.data.products;
    }  
     
    else 
    {  
      console.error('No products found in the API response');  
      throw new Error('No products found');  
      // throw new Error("No products found");  
    }  
  }
catch (error) {  
  console.error('Error fetching products:', error);  
  // Throwing the error so it can be caught in the rejected case  
  throw error;  
} 

});  


const cartSlice = createSlice({
name: 'cart',
initialState: 
    {
    items: [],
    },

 reducers: {
   addToCart: (state, action) => {
        state.items.push(action.payload);
   },
   removeFromCart: (state, action) => {
        state.items = state.items.filter(item => item.id !== action.payload);
   },
   clearCart: state => {
        state.items = [];
   },
 },
 extraReducers: (builder) => {  
     builder  
       .addCase(fetchProducts.fulfilled, (state, action) => {  
         //state.products = action.payload || [{id: 1, name: 'Test Product'}];;  
         console.log("fetchProducts.fulfilled triggered");  
         console.log("Products payload", action.payload);
         state.products=action.payload;
         state.loading = false;
       })
       .addCase(fetchProducts.pending, (state) => {  
         state.loading = true;  
         state.error = null;
       })
       .addCase(fetchProducts.rejected, (state, action) => {  
         state.loading = false; // Set loading to false  
         state.error = action.error.message; // Set error message if needed  
         console.error('Failed to fetch products:', action.error.message); // Error handling    
       });
   }  
});

export const { addToCart, removeFromCart, clearCart } = cartSlice.actions;
export default cartSlice.reducer;