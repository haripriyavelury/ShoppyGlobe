import React from 'react';
import { useDispatch } from 'react-redux';
import { addToCart } from '../redux/cartSlice';

const ProductItem = ({ product }) => {
 const dispatch = useDispatch();


const handleAddToCart = () => {  
  dispatch(addToCart(product));
  // dispatch(addToCart({ id: product.id, name: product.title, 
  //   description: product.description, price: product.price, rating: product.rating}));  
console.log("Item added to cart",product)};  


return (
//{/* <div>
//<h3>{product.name}</h3>
//<p>{product.description}</p>
//<button onClick={() => dispatch(addToCart(product))}>Add to Cart</button>
//</div> */}


<div className='product-item'>  
   
   <img className="product-image" src={product.thumbnail} alt="{product.title}"/>
 
     <h3>{product.title}</h3>  
     <p>DESC: {product.description}</p>  
     <p>Price: {product.price}</p>
     <p>Rating: {product.rating}</p>
    
     <button className="button" onClick={handleAddToCart}>Add to Cart</button>  
   </div>  


 );
};

export default ProductItem;