import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import '../App.css'; 

const ProductDetail = () => {
 const { id } = useParams();
 const [product, setProduct] = useState(null);
 const [loading, setLoading] = useState(true);
 const [error, setError] = useState(false);

 useEffect(() => {
   const fetchProductDetail = async () => {
    try {
    const response = await axios.get(`https://dummyjson.com/products/${id}`);
    setProduct(response.data);
    } catch (err) {
       setError(true);
    } finally {
    setLoading(false);
    }
   };

   fetchProductDetail();
 }, [id]);

if (loading) return <p>Loading...</p>;
if (error) return <p>There was an error fetching the product.</p>;

return (
<div>
 <h3>{product.title}</h3>  
  <p>DESC: {product.description}</p>  
  <p>Price: {product.price}</p>  
  <p>Rating: {product.rating}</p>
  <p>{product.thumbnail}</p>   
</div>
);
};

export default ProductDetail;